# 概要
## やりたいこと
- インターネット回線を経由せずに、別アカウントのS3にファイルをUPLOADしたい。
- VPC内lambdaより、S3アクセスポイント経由でUPLOADしたい。

## 前提
- アカウントは２個（DevとPrd）を準備下さい。
- AdministratorAccessポリシーのあるプログラムによるアクセス可能なIAMユーザーをアカウントそれぞれで準備下さい。
- リージョンは東京リージョン（ap-northeast-1）を利用します。
- result結果を貼り付けていますが、IDについては厳密には同じ値ではないです。環境によって異なりますので読み替えをお願いします。

## 俯瞰図
![image](./image/STS-image01.png)




# 01.手順概要(アカウントDev)
- アカウントDevでのIAM Roleを作成する

![image](./image/STS-image02.png)

## 01-01.AWS構成変更
- プロファイル名は"AWS-CLI-DEV"としていますが、適宜変更下さい。

### cmd
```
export AWS_DEFAULT_REGION="ap-northeast-1"
export AWS_DEFAULT_PROFILE="AWS-CLI-DEV"
```
### result
```
none
```



## 01-02.AWS構成確認
- profileがAWS-CLI-DEVであることを確認
- regionがap-northeast-1であることを確認

### cmd
```
aws configure list
```
### result
```
      Name                    Value             Type    Location
      ----                    -----             ----    --------
   profile              AWS-CLI-DEV           manual    --profile
access_key     ****************V6XR shared-credentials-file    
secret_key     ****************xNsI shared-credentials-file    
    region           ap-northeast-1              env    ['AWS_REGION', 'AWS_DEFAULT_REGION']
```



## 01-03.アカウントID取得
- アカウントIDは利用者事に異なります、111111111111は仮です。

### cmd
```
DevAccountId=`aws sts get-caller-identity \
  --query 'Account' \
  --output text` && echo ${DevAccountId}
```

### result
```
111111111111
```



## 01-04.IAM Roleの信頼関係作成用ポリシーファイル作成
- lambdaとstsから利用可能なIAM Roleにするポリシーを記述

### cmd
```
cat << EOF > DevIamRoleTrustPolicy.json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": [
          "lambda.amazonaws.com",
          "sts.amazonaws.com"
        ]
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF
```

### result
```
none
```



## 01-05.jsonファイルが正しいか確認
- jsonlintがインストールされていない方は[こちら](https://github.com/zaach/jsonlint)から

### cmd
```
jsonlint -q DevIamRoleTrustPolicy.json
```

### result
```
none
```



## 01-06.IAM Roleの作成
- resultから抜けるには"Q"を押下。

### cmd
```
DevRoleName='@DevHandsOnRole'
```

```
aws iam create-role \
  --role-name ${DevRoleName} \
  --assume-role-policy-document file://DevIamRoleTrustPolicy.json
```
### result
```
none
```

```
{
    "Role": {
        "Path": "/",
        "RoleName": "@DevHandsOnRole",
        "RoleId": "AROAVQKJMMMIK4G5MIODM",
        "Arn": "arn:aws:iam::111111111111:role/@DevHandsOnRole",
        "CreateDate": "2020-10-18T08:15:19+00:00",
        "AssumeRolePolicyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {
                        "Service": [
                            "lambda.amazonaws.com",
                            "sts.amazonaws.com"
                        ]
                    },
                    "Action": "sts:AssumeRole"
                }
            ]
        }
    }
}
```



## 01-07.IAM Roleへの権限付与①
- AWSLambdaBasicExecutionRoleを付与

### cmd
```
aws iam attach-role-policy \
--role-name ${DevRoleName} \
--policy-arn "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
```

### result
```
none
```



## 01-08.Roleへの権限付与②
- AmazonEC2FullAccessを付与

### cmd
```
aws iam attach-role-policy \
--role-name ${DevRoleName} \
--policy-arn "arn:aws:iam::aws:policy/AmazonEC2FullAccess"
```

### result
```
none
```



## 01-09.ポリシーファイル作成
- AssumeRoleを可能とするポリシーファイル作成

### cmd
```
cat << EOF > DevIamPolicyDocument.json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "sts:AssumeRole"
            ],
            "Resource": "*"
        }
    ]
}
EOF
```

### result
```
none
```



## 01-10.jsonファイルが正しいか確認

### cmd
```
jsonlint -q DevIamPolicyDocument.json
```

### result
```
none
```


## 01-11.ポリシー適用
### cmd
```
aws iam put-role-policy \
  --role-name ${DevRoleName} \
  --policy-name "AssumeRole" \
  --policy-document file://DevIamPolicyDocument.json
```

### result
```
none
```





# 02.手順概要(アカウントDev)
- VPCとSUBNETを作成する。
- SUBNETは3個作成する。

![image](./image/STS-image03.png)

## 02-01.VPC作成
- resultから抜けるには"Q"を押下。

### cmd
```
aws ec2 create-vpc \
    --cidr-block 10.0.0.0/16 \
    --tag-specifications 'ResourceType=vpc,Tags=[{Key=Name,Value=DevHandsOn}]'
```
### result
```
{
    "Vpc": {
        "CidrBlock": "10.0.0.0/16",
        "DhcpOptionsId": "dopt-d50f23b2",
        "State": "pending",
        "VpcId": "vpc-0718cf5c3dd30b5c5",
        "OwnerId": "111111111111",
        "InstanceTenancy": "default",
        "Ipv6CidrBlockAssociationSet": [],
        "CidrBlockAssociationSet": [
            {
                "AssociationId": "vpc-cidr-assoc-0f574c946d90ca684",
                "CidrBlock": "10.0.0.0/16",
                "CidrBlockState": {
                    "State": "associated"
                }
            }
        ],
        "IsDefault": false,
        "Tags": [
            {
                "Key": "Name",
                "Value": "DevHandsOn"
            }
        ]
    }
}
```



## 02-02.VpcIdの取得
- resultのVpcIdは一例です。

### cmd
```
VpcId=`aws ec2 describe-vpcs \
  --filters "Name=tag-key,Values=Name" \
            "Name=tag-value,Values=DevHandsOn" \
  --query 'Vpcs[].VpcId[]' \
  --output text` && echo ${VpcId}
```

### result
```
vpc-0718cf5c3dd30b5c5
```



## 02-03.RouteTableIdの取得
- resultのRouteTableIdは一例です。

### cmd
```
RouteTableId=`
aws ec2 describe-route-tables \
  --filters "Name=vpc-id,Values=${VpcId}" \
  --query 'RouteTables[0].RouteTableId' \
  --output text` && echo ${RouteTableId}
```

### result
```
rtb-033dea026d90ad4a0
```



## 02-04.SecurityGroupIdの取得
- resultのSecurityGroupIdは一例です。
### cmd
```
SecurityGroupId=`aws ec2 describe-security-groups \
  --filters "Name=vpc-id,Values=${VpcId}" \
  --query 'SecurityGroups[].GroupId'` && echo ${SecurityGroupId}
```
### result
```
[
    "sg-0df36a08fec0cbf5a"
]
```


## 02-05.VPCのDNS有効化確認
### cmd
```
aws ec2 modify-vpc-attribute \
  --vpc-id ${VpcId} \
  --enable-dns-hostnames "{\"Value\":true}"
```

```
aws ec2 modify-vpc-attribute \
  --vpc-id ${VpcId} \
  --enable-dns-support "{\"Value\":true}"
```

### result
```
none
```

```
none
```



## 02-06.SUBNET作成
- 3つSUBNETを作成します。
- resultから抜けるには"Q"を押下。
### cmd
```
aws ec2 create-subnet \
  --vpc-id ${VpcId} \
  --cidr-block 10.0.1.0/24 \
  --availability-zone ap-northeast-1a \
  --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=DevHandsOn}]'
```

```
aws ec2 create-subnet \
  --vpc-id ${VpcId} \
  --cidr-block 10.0.2.0/24 \
  --availability-zone ap-northeast-1c \
  --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=DevHandsOn}]'
```

```
aws ec2 create-subnet \
  --vpc-id ${VpcId} \
  --cidr-block 10.0.3.0/24 \
  --availability-zone ap-northeast-1d \
  --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=DevHandsOn}]'
```


### result
```
{
    "Subnet": {
        "AvailabilityZone": "ap-northeast-1a",
        "AvailabilityZoneId": "apne1-az4",
        "AvailableIpAddressCount": 251,
        "CidrBlock": "10.0.1.0/24",
        "DefaultForAz": false,
        "MapPublicIpOnLaunch": false,
        "State": "available",
        "SubnetId": "subnet-0fb41eb669d8843bc",
        "VpcId": "vpc-0718cf5c3dd30b5c5",
        "OwnerId": "111111111111",
        "AssignIpv6AddressOnCreation": false,
        "Ipv6CidrBlockAssociationSet": [],
        "Tags": [
            {
                "Key": "Name",
                "Value": "DevHandsOn"
            }
        ],
        "SubnetArn": "arn:aws:ec2:ap-northeast-1:111111111111:subnet/subnet-0fb41eb669d8843bc"
    }
}
```

```
{
    "Subnet": {
        "AvailabilityZone": "ap-northeast-1c",
        "AvailabilityZoneId": "apne1-az1",
        "AvailableIpAddressCount": 251,
        "CidrBlock": "10.0.2.0/24",
        "DefaultForAz": false,
        "MapPublicIpOnLaunch": false,
        "State": "available",
        "SubnetId": "subnet-0fbc32308c5edd37a",
        "VpcId": "vpc-0718cf5c3dd30b5c5",
        "OwnerId": "111111111111",
        "AssignIpv6AddressOnCreation": false,
        "Ipv6CidrBlockAssociationSet": [],
        "Tags": [
            {
                "Key": "Name",
                "Value": "DevHandsOn"
            }
        ],
        "SubnetArn": "arn:aws:ec2:ap-northeast-1:111111111111:subnet/subnet-0fbc32308c5edd37a"
    }
}
```

```
{
    "Subnet": {
        "AvailabilityZone": "ap-northeast-1d",
        "AvailabilityZoneId": "apne1-az2",
        "AvailableIpAddressCount": 251,
        "CidrBlock": "10.0.3.0/24",
        "DefaultForAz": false,
        "MapPublicIpOnLaunch": false,
        "State": "available",
        "SubnetId": "subnet-04dd93ef1afe35a0f",
        "VpcId": "vpc-0718cf5c3dd30b5c5",
        "OwnerId": "111111111111",
        "AssignIpv6AddressOnCreation": false,
        "Ipv6CidrBlockAssociationSet": [],
        "Tags": [
            {
                "Key": "Name",
                "Value": "DevHandsOn"
            }
        ],
        "SubnetArn": "arn:aws:ec2:ap-northeast-1:111111111111:subnet/subnet-04dd93ef1afe35a0f"
    }
}
```

## 02-07.SubnetIdの取得
- resultのSubnetIdは一例です。
### cmd
```
SubnetId=`aws ec2 describe-subnets \
  --filters "Name=vpc-id,Values=${VpcId}" \
  --query 'Subnets[].SubnetId' \
  --output json` && echo ${SubnetId}
```

### result
```
[
    "subnet-04dd93ef1afe35a0f",
    "subnet-0fb41eb669d8843bc",
    "subnet-0fbc32308c5edd37a"
]
```


# 03.手順概要(アカウントDev)
- VPCエンドポイントS3とSTSを作成する
- S3のエンドポイントは「ゲートウェイエンドポイント」で１個作成される
- STSのエンドポイントは「インターフェイスエンドポイント」で紐付けたSUBNETの個数分作成される

![image](./image/STS-image04.png)

## 03-01.S3エンドポイント作成
- resultから抜けるには"Q"を押下。

### cmd
```
aws ec2 create-vpc-endpoint \
    --vpc-id ${VpcId} \
    --service-name com.amazonaws.ap-northeast-1.s3 \
    --route-table-ids ${RouteTableId} \
    --tag-specifications 'ResourceType=vpc-endpoint,Tags=[{Key=Name,Value=DevHandsOn}]'
```

### result
```
{
    "VpcEndpoint": {
        "VpcEndpointId": "vpce-02cb7f6235fb21319",
        "VpcEndpointType": "Gateway",
        "VpcId": "vpc-0718cf5c3dd30b5c5",
        "ServiceName": "com.amazonaws.ap-northeast-1.s3",
        "State": "available",
        "PolicyDocument": "{\"Version\":\"2008-10-17\",\"Statement\":[{\"Effect\":\"Allow\",\"Principal\":\"*\",\"Action\":\"*\",\"Resource\":\"*\"}]}",
        "RouteTableIds": [
            "rtb-033dea026d90ad4a0"
        ],
        "SubnetIds": [],
        "Groups": [],
        "PrivateDnsEnabled": false,
        "RequesterManaged": false,
        "NetworkInterfaceIds": [],
        "DnsEntries": [],
        "CreationTimestamp": "2020-10-18T08:26:01+00:00",
        "Tags": [
            {
                "Key": "Name",
                "Value": "DevHandsOn"
            }
        ],
        "OwnerId": "111111111111"
    }
}
```


## 03-02.STSエンドポイント作成
- resultから抜けるには"Q"を押下。

### cmd
```
aws ec2 create-vpc-endpoint \
    --vpc-id ${VpcId} \
    --vpc-endpoint-type Interface \
    --service-name com.amazonaws.ap-northeast-1.sts \
    --subnet-id ${SubnetId} \
    --security-group-id ${SecurityGroupId} \
    --tag-specifications 'ResourceType=vpc-endpoint,Tags=[{Key=Name,Value=DevHandsOn}]'
```

### result
```
{
    "VpcEndpoint": {
        "VpcEndpointId": "vpce-0738109559bf72011",
        "VpcEndpointType": "Interface",
        "VpcId": "vpc-0718cf5c3dd30b5c5",
        "ServiceName": "com.amazonaws.ap-northeast-1.sts",
        "State": "pending",
        "RouteTableIds": [],
        "SubnetIds": [
            "subnet-04dd93ef1afe35a0f",
            "subnet-0fb41eb669d8843bc",
            "subnet-0fbc32308c5edd37a"
        ],
        "Groups": [
            {
                "GroupId": "sg-0df36a08fec0cbf5a",
                "GroupName": "default"
            }
        ],
        "PrivateDnsEnabled": true,
        "RequesterManaged": false,
        "NetworkInterfaceIds": [
            "eni-04f04f8023fa7a595",
            "eni-012466b24d3a5d984",
            "eni-01c4f822844d80a30"
        ],
        "DnsEntries": [
            {
                "DnsName": "vpce-0738109559bf72011-j1b86uvw.sts.ap-northeast-1.vpce.amazonaws.com",
                "HostedZoneId": "Z2E726K9Y6RL4W"
            },
            {
                "DnsName": "vpce-0738109559bf72011-j1b86uvw-ap-northeast-1a.sts.ap-northeast-1.vpce.amazonaws.com",
                "HostedZoneId": "Z2E726K9Y6RL4W"
            },
            {
                "DnsName": "vpce-0738109559bf72011-j1b86uvw-ap-northeast-1d.sts.ap-northeast-1.vpce.amazonaws.com",
                "HostedZoneId": "Z2E726K9Y6RL4W"
            },
            {
                "DnsName": "vpce-0738109559bf72011-j1b86uvw-ap-northeast-1c.sts.ap-northeast-1.vpce.amazonaws.com",
                "HostedZoneId": "Z2E726K9Y6RL4W"
            },
            {
                "DnsName": "sts.ap-northeast-1.amazonaws.com",
                "HostedZoneId": "ZONEIDPENDING"
            }
        ],
        "CreationTimestamp": "2020-10-18T08:26:29.503000+00:00",
        "Tags": [
            {
                "Key": "Name",
                "Value": "DevHandsOn"
            }
        ],
        "OwnerId": "111111111111"
    }
}
```



# ０4.手順概要(アカウントDev)
- Lamdaの作成
- VPCに紐付けた場合、専用ネットワークから、ENIを介してVPCへアクセスする
- NICの数は紐付けたSUBNETの数となる。

![image](./image/STS-image05.png)

## 04-01.Lambda Code準備（仮）
### cmd
```
cat << EOF > lambda_function.py
import json

def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
EOF
```

### result
```
none
```

## 04-02.Lambda Codeの圧縮（仮）
### cmd
```
ls -l lambda_function*
```

```
zip -r lambda_function.zip lambda_function.py
ls -l lambda_function*
```

### result
```
-rw-r--r--  1 shigeruoda  staff  165 10 18 17:30 lambda_function.py
```

```
  adding: lambda_function.py (deflated 19%)
-rw-r--r--  1 shigeruoda  staff  165 10 18 17:30 lambda_function.py
-rw-r--r--  1 shigeruoda  staff  320 10 18 17:30 lambda_function.zip
```



## 04-03.Lambda function名設定
### cmd
```
FunctionName="HandsOnLambda" \
&& echo ${FunctionName}
```

### result
```
HandsOnLambda
```



## 04-04.Lambda 作成
- resultから抜けるには"Q"を押下。

### cmd
```
aws lambda create-function \
    --function-name ${FunctionName} \
    --runtime python3.8 \
    --zip-file fileb://lambda_function.zip \
    --handler lambda_function.lambda_handler \
    --role "arn:aws:iam::${DevAccountId}:role/${DevRoleName}" \
    --vpc-config SubnetIds=${SubnetId},SecurityGroupIds=${SecurityGroupId}
```

### result
```
{
    "FunctionName": "HandsOnLambda",
    "FunctionArn": "arn:aws:lambda:ap-northeast-1:111111111111:function:HandsOnLambda",
    "Runtime": "python3.8",
    "Role": "arn:aws:iam::111111111111:role/@DevHandsOnRole",
    "Handler": "lambda_function.lambda_handler",
    "CodeSize": 320,
    "Description": "",
    "Timeout": 3,
    "MemorySize": 128,
    "LastModified": "2020-10-18T08:31:32.087+0000",
    "CodeSha256": "kgdAvYE2nN3yx+dKZDPz/eESv7i3oFysPbSxnKGC7j4=",
    "Version": "$LATEST",
    "VpcConfig": {
        "SubnetIds": [
            "subnet-0fb41eb669d8843bc",
            "subnet-0fbc32308c5edd37a",
            "subnet-04dd93ef1afe35a0f"
        ],
        "SecurityGroupIds": [
            "sg-0df36a08fec0cbf5a"
        ],
        "VpcId": "vpc-0718cf5c3dd30b5c5"
    },
    "TracingConfig": {
        "Mode": "PassThrough"
    },
    "RevisionId": "750b64b4-f137-4fe3-8ceb-b803d7556ade",
    "State": "Pending",
    "StateReason": "The function is being created.",
    "StateReasonCode": "Creating"
}
```





# ０5.手順概要(アカウントPrd)
- S3バゲットとアクセスポイントの作成

![image](./image/STS-image06.png)

## 05-01.AWS構成変更
- プロファイル名は"AWS-CLI-PRD"としていますが、適宜変更下さい。

### cmd
```
export AWS_DEFAULT_REGION="ap-northeast-1"
export AWS_DEFAULT_PROFILE="AWS-CLI-PRD"
```
### result
```
none
```



## 05-02.AWS構成確認
- profileがAWS-CLI-PRDであることを確認
- regionがap-northeast-1であることを確認

### cmd
```
aws configure list
```
### result
```
      Name                    Value             Type    Location
      ----                    -----             ----    --------
   profile              AWS-CLI-PRD           manual    --profile
access_key     ****************V6XR shared-credentials-file    
secret_key     ****************xNsI shared-credentials-file    
    region           ap-northeast-1              env    ['AWS_REGION', 'AWS_DEFAULT_REGION']
```


## 05-03.アカウントID取得
- アカウントIDは利用者事に異なります、222222222222は仮です。
### cmd
```
PrdAccountId=`aws sts get-caller-identity \
  --query 'Account' \
  --output text` && echo ${PrdAccountId}
```

### result
```
222222222222
```

## 05-04.S3のバケット名設定
- YourNameは適宜ご自身のお名前に変更して下さい。小文字である必要があります。
- S3バケット名は世界で一意になる必要があります。

### cmd
```
YourName="shigeruoda" \
&& echo ${YourName}
```

```
BucketName="${YourName}-handson-$(date +%Y%m%d%H%M%S)" \
&& echo ${BucketName}
```

### result
```
shigeruoda
```

```
shigeruoda-handson-20201018173450
```

## 05-05.S3のバケット作成
### cmd
```
aws s3api create-bucket \
  --bucket ${BucketName} \
  --region ap-northeast-1 \
  --create-bucket-configuration LocationConstraint=ap-northeast-1
```

### result
```
{
    "Location": "http://shigeruoda-handson-20201018173450.s3.amazonaws.com/"
}
```



## 05-06.S3アクセスポイント名設定
- LambdaがUPLOADするアクセスポイント名を設定します

### cmd
```
AccessPointName="ap-${BucketName}" \
&& echo ${AccessPointName}
```

### result
```
ap-shigeruoda-handson-20201018173450
```



## 05-07.S3アクセスポイント作成
### cmd
```
aws s3control create-access-point \
  --account-id ${PrdAccountId} \
  --bucket ${BucketName} \
  --name ${AccessPointName} \
  --vpc-configuration "VpcId"=${VpcId}
```

### result
```
none
```



## 05-08.S3 ARN設定
### cmd
```
S3Arn="arn:aws:s3:::${BucketName}" \
&& echo ${S3Arn}
```

```
S3ApArn="arn:aws:s3:ap-northeast-1:${PrdAccountId}:accesspoint/${AccessPointName}" \
&& echo ${S3ApArn}
```

### result
```
arn:aws:s3:::shigeruoda-handson-20201018173450
```

```
arn:aws:s3:ap-northeast-1:222222222222:accesspoint/ap-shigeruoda-handson-20201018173450

```


## 05-09.S3バゲットポリシーファイル作成
- アクセスポイント経由じゃないとS3 Putは許可しないポリシーファイル作成
### cmd
```
cat << EOF > PrdS3BucketPolicy.json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": "*",
            "Action": [
                "s3:PutObject"
            ],
            "Resource": "${S3Arn}/*",
            "Condition": {
                "StringEquals": {
                    "s3:DataAccessPointArn": "${S3ApArn}"
                }
            }
        }
    ]
}
EOF
```

### result
```
none
```



## 05-10.jsonファイルが正しいか確認
### cmd
```
jsonlint -q PrdS3BucketPolicy.json
```

### result
```
none
```



## 05-11.バゲットポリシー適用
### cmd
```
aws s3api put-bucket-policy \
  --bucket ${BucketName} \
  --policy file://PrdS3BucketPolicy.json
```
### result
```
none
```


# ０6.手順概要(アカウントPrd)
- Role作成

![image](./image/STS-image07.png)


## 06-01.Roleの信頼関係作成用ポリシーファイル作成
- 外部IDを設定し、そのIDを知っているアカウントのみ利用を許可する。
### cmd
```
cat << EOF > PrdIamRoleTrustPolicy.json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::${DevAccountId}:role/${DevRoleName}"
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "StringEquals": {
          "sts:ExternalId": "ExternalId-1234567890"
        }
      }
    }
  ]
}
EOF
```

### result
```
none
```



## 06-02.jsonファイルが正しいか確認
### cmd
```
jsonlint -q PrdIamRoleTrustPolicy.json
```

### result
```
none
```


## 06-02.Roleの作成
- resultから抜けるには"Q"を押下。

### cmd
```
PrdRoleName='@PrdHandsOnRole'
```

```
aws iam create-role \
  --role-name ${PrdRoleName} \
  --assume-role-policy-document file://PrdIamRoleTrustPolicy.json
```


### result
```
none
```

```
{
    "Role": {
        "Path": "/",
        "RoleName": "@PrdHandsOnRole",
        "RoleId": "AROAQ3DTYIKY4P7A5MA3O",
        "Arn": "arn:aws:iam::222222222222:role/@PrdHandsOnRole",
        "CreateDate": "2020-10-18T08:37:01+00:00",
        "AssumeRolePolicyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {
                        "AWS": "arn:aws:iam::111111111111:role/@DevHandsOnRole"
                    },
                    "Action": "sts:AssumeRole",
                    "Condition": {
                        "StringEquals": {
                            "sts:ExternalId": "ExternalId-1234567890"
                        }
                    }
                }
            ]
        }
    }
}
```


## 06-03.Roleのポリシーファイル作成
### cmd
```
cat << EOF > ProIamPolicyDocument.json
{
  "Version": "2012-10-17",
  "Statement": [
      {
          "Sid": "VisualEditor0",
          "Effect": "Allow",
          "Action": "s3:PutObject",
          "Resource": "${S3ApArn}/*"
      }
  ]
}
EOF
```

### reulst
```
none
```



## 06-04.jsonファイルが正しいか確認
### cme
```
jsonlint -q ProIamPolicyDocument.json
```

### result
```
none
```


## 06-05.Roleへの権限付与
### cmd
```
aws iam put-role-policy \
--role-name ${PrdRoleName} \
--policy-name inline \
--policy-document file://ProIamPolicyDocument.json
```

### result
```
none
```




# ０7.手順概要(アカウントPrd)
- lambdaのコードを変更する。
- STSから一時クレデンシャル情報を取得する。
- S3にAP経由でUPLOADする

![image](./image/STS-image08.png)


## 07-01.AWS構成変更
### cmd
```
export AWS_DEFAULT_REGION="ap-northeast-1"
export AWS_DEFAULT_PROFILE="AWS-CLI-DEV"
```
### result
```
none
```



## 07-02.AWS構成確認
- profileがAWS-CLI-DEVであることを確認
- regionがap-northeast-1であることを確認

### cmd
```
aws configure list
```
### result
```
      Name                    Value             Type    Location
      ----                    -----             ----    --------
   profile              AWS-CLI-DEV           manual    --profile
access_key     ****************V6XR shared-credentials-file    
secret_key     ****************xNsI shared-credentials-file    
    region           ap-northeast-1              env    ['AWS_REGION', 'AWS_DEFAULT_REGION']
```

## 07-03.Lambda Code準備
- ”一時クレデンシャル情報取得”の際に、外部IDを設定していることを注目

### cmd
```
cat << EOF > lambda_function.py
import json
import boto3
def lambda_handler(event, context):
    ######
    # Dev側の情報出力
    sts = boto3.client('sts', region_name="ap-northeast-1", endpoint_url="https://sts.ap-northeast-1.amazonaws.com/")
    response = sts.get_caller_identity()
    print(response['Arn'])
    
    ######
    # 一時クレデンシャル情報取得
    role_info = sts.assume_role(
        RoleArn="arn:aws:iam::222222222222:role/@PrdHandsOnRole",
        RoleSessionName="PrdHandsOnRole",
        ExternalId="ExternalId-1234567890"
    )
   
    # AssumedRoleUser側の情報出力
    print(role_info['AssumedRoleUser']['Arn'])
    ACCESS_KEY = role_info['Credentials']['AccessKeyId']
    SECRET_KEY = role_info['Credentials']['SecretAccessKey']
    SESSION_TOKEN = role_info['Credentials']['SessionToken']

    ######
    # S3バケットへのUpload
    try:
        bucket_name="shigeruoda-handson-20201018173450"
        json_key = 'bucket.json'
        
        s3 = boto3.resource(
            's3',
            aws_access_key_id=ACCESS_KEY,
            aws_secret_access_key=SECRET_KEY,
            aws_session_token=SESSION_TOKEN,
        )
        
        obj = s3.Object(bucket_name,json_key)
        test_json = {'key': 'value'}
        r = obj.put(Body = json.dumps(test_json))
        print(r)
        
        print('OK:S3バケットへのUpload')
        bucket_upload='OK'
    except:
        print('NG:S3バケットへのUpload')
        bucket_upload='NG'
    
    ######
    # S3アクセスポイントへのUpload
    try:
        bucket_name="arn:aws:s3:ap-northeast-1:222222222222:accesspoint/ap-shigeruoda-handson-20201018173450"
        json_key = 'ap.json'
        
        s3 = boto3.resource(
            's3',
            aws_access_key_id=ACCESS_KEY,
            aws_secret_access_key=SECRET_KEY,
            aws_session_token=SESSION_TOKEN,
        )
        
        obj = s3.Object(bucket_name,json_key)
        test_json = {'key': 'value'}
        r = obj.put(Body = json.dumps(test_json))
        print(r)
        
        print('OK:S3アクセスポイントへのUpload')
        ap_upload='OK'

    except:
        print('NG:S3アクセスポイントへのUpload')
        ap_upload='NG'

    # TODO implement
    return {
        'statusCode': 200,
        'bucket_upload': bucket_upload,
        'ap_upload': ap_upload,
        'body': json.dumps('Hello from Lambda!')
    }
EOF
```

### result
```
none
```



## 07-04.Lambda Codeの圧縮
### cmd
```
ls -l lambda_function*
```

```
zip -r lambda_function.zip lambda_function.py
ls -l lambda_function*
```

### result
```
-rw-r--r--  1 shigeruoda  staff  2420 10 18 17:43 lambda_function.py
-rw-r--r--  1 shigeruoda  staff   320 10 18 17:30 lambda_function.zip
→ 現時点のzipは以前作成した物
```

```
updating: lambda_function.py (deflated 64%)
-rw-r--r--  1 shigeruoda  staff  2420 10 18 17:43 lambda_function.py
-rw-r--r--  1 shigeruoda  staff  1063 10 18 17:43 lambda_function.zip
→ 現時点のzipは今作成した物
```



## 07-05.Lambda 更新
- resultから抜けるには"Q"を押下。
### cmd
```
aws lambda update-function-code \
    --function-name ${FunctionName} \
    --zip-file fileb://lambda_function.zip
```

### result
```
{
    "FunctionName": "HandsOnLambda",
    "FunctionArn": "arn:aws:lambda:ap-northeast-1:111111111111:function:HandsOnLambda",
    "Runtime": "python3.8",
    "Role": "arn:aws:iam::111111111111:role/@DevHandsOnRole",
    "Handler": "lambda_function.lambda_handler",
    "CodeSize": 1008,
    "Description": "",
    "Timeout": 3,
    "MemorySize": 128,
    "LastModified": "2020-10-18T08:44:51.651+0000",
    "CodeSha256": "S9WCkAbB73U3O1hkyCBKVFH6L27dJE7H6rNZKhF3E/U=",
    "Version": "$LATEST",
    "VpcConfig": {
        "SubnetIds": [
            "subnet-0fb41eb669d8843bc",
            "subnet-0fbc32308c5edd37a",
            "subnet-04dd93ef1afe35a0f"
        ],
        "SecurityGroupIds": [
            "sg-0df36a08fec0cbf5a"
        ],
        "VpcId": "vpc-0718cf5c3dd30b5c5"
    },
    "TracingConfig": {
        "Mode": "PassThrough"
    },
    "RevisionId": "cf7de3ee-b29c-456e-ba18-a4e046259444",
    "State": "Active",
    "LastUpdateStatus": "Successful"
}
```



## 07-06.Lambda 実行
### cmd
```
aws lambda invoke \
    --cli-binary-format raw-in-base64-out \
    --function-name ${FunctionName} \
    --payload '{ "key": "value" }' \
    --log-type Tail \
    --query 'LogResult' \
    response.json | tr -d '"' | base64 -D
```

### result
```
START RequestId: fc32e74a-9a4e-46d5-8c56-e24815c2627e Version: $LATEST
arn:aws:sts::111111111111:assumed-role/@DevHandsOnRole/HandsOnLambda
arn:aws:sts::222222222222:assumed-role/@PrdHandsOnRole/PrdHandsOnRole
NG:S3バケットへのUpload
{'ResponseMetadata': {'RequestId': 'ECD35789ABA36484', 'HostId': 'vI3n3QlJtes+6JMTwNzixUtU5Bf+5ClKb7s7pSxOpFzNIbI7Lo8uT2LyCXLpgyKAG2H4RoXH3Aw=', 'HTTPStatusCode': 200, 'HTTPHeaders': {'x-amz-id-2': 'vI3n3QlJtes+6JMTwNzixUtU5Bf+5ClKb7s7pSxOpFzNIbI7Lo8uT2LyCXLpgyKAG2H4RoXH3Aw=', 'x-amz-request-id': 'ECD35789ABA36484', 'date': 'Sun, 18 Oct 2020 09:28:06 GMT', 'etag': '"88bac95f31528d13a072c05f2a1cf371"', 'content-length': '0', 'server': 'AmazonS3'}, 'RetryAttempts': 0}, 'ETag': '"88bac95f31528d13a072c05f2a1cf371"'}
OK:S3アクセスポイントへのUpload
END RequestId: fc32e74a-9a4e-46d5-8c56-e24815c2627e
REPORT RequestId: fc32e74a-9a4e-46d5-8c56-e24815c2627e  Duration: 1259.68 ms    Billed Duration: 1300 ms        Memory Size: 128 MB     Max Memory Used: 82 MB
```



# 08.確認作業(アカウントPrd)
## 08-01.S3の結果確認
- アクセスポイント経由でのUPLOADされたファイル(ap.json)があること確認。
- バケット経由でのUPLOADされたファイル(bucket.json)がないこと確認。
- 
![image](./image/result01.png)




# 09.削除作業(アカウントPrd)
## 09-01.AWS構成変更
- プロファイル名は"AWS-CLI-PRD"としていますが、適宜変更下さい。

### cmd
```
export AWS_DEFAULT_REGION="ap-northeast-1"
export AWS_DEFAULT_PROFILE="AWS-CLI-PRD"
```
### result
```
none
```



## 09-02.AWS構成確認
- profileがAWS-CLI-PRDであることを確認
- regionがap-northeast-1であることを確認

### cmd
```
aws configure list
```
### result
```
      Name                    Value             Type    Location
      ----                    -----             ----    --------
   profile              AWS-CLI-PRD           manual    --profile
access_key     ****************SCUW shared-credentials-file    
secret_key     ****************aPba shared-credentials-file    
    region           ap-northeast-1              env    ['AWS_REGION', 'AWS_DEFAULT_REGION']
```



## 09-03.S3アクセスポイントの削除
### cmd
```
aws s3control delete-access-point \
  --account-id ${PrdAccountId} \
  --name ${AccessPointName}
```

### result
```
none
```


## 09-04.S3バケットオブジェクトの削除
### cmd
```
aws s3api delete-object \
  --bucket ${BucketName} \
  --key ap.json
```
```
aws s3api delete-object \
  --bucket ${BucketName} \
  --key bucket.json
```

### result
```
none
```
```
none
```




## 09-04.S3バゲットの削除
### cmd
```
aws s3api delete-bucket \
  --bucket ${BucketName}
```

### result
```
none
```


## 09-05.IAM RolePolicyの削除
### cmd
```
aws iam delete-role-policy \
--role-name ${PrdRoleName} \
--policy-name "inline"
```

### result
```
none
```

## 09-06.IAM Roleの削除
### cmd
```
aws iam delete-role \
  --role-name ${PrdRoleName}
```

### result
```
none
```

# 10.削除作業(アカウントDev)
## 10-01.AWS構成変更
- プロファイル名は"AWS-CLI-DEV"としていますが、適宜変更下さい。

### cmd
```
export AWS_DEFAULT_REGION="ap-northeast-1"
export AWS_DEFAULT_PROFILE="AWS-CLI-DEV"
```

### result
```
none
```



## 10-02.AWS構成確認
- profileがAWS-CLI-DEVであることを確認
- regionがap-northeast-1であることを確認

### cmd
```
aws configure list
```
### result
```
none
```




## 10-03.Lambdaの削除
### cmd
```
aws lambda delete-function \
  --function-name ${FunctionName}
```
### result
```
none
```


## 10-04.VPCエンドポイントIDの取得
### cmd
```
VpcEndpointIds=`aws ec2 describe-vpc-endpoints \
  --filter Name=vpc-id,Values=${VpcId} \
  --query "VpcEndpoints[*].VpcEndpointId"` \
  && echo ${VpcEndpointIds}
```
### result
```
[
    "vpce-02cb7f6235fb21319",
    "vpce-0738109559bf72011"
]
```

## 10-05.VPCエンドポイントの削除
### cmd
```
aws ec2 delete-vpc-endpoints \
  --vpc-endpoint-ids ${VpcEndpointIds}
```
### result
```
{
    "Unsuccessful": []
}
```


## 10-06.SUBNET IDの取得
- ここ手順がいまいち・・・

### cmd
```
SubnetId0=`aws ec2 describe-subnets \
  --filters "Name=vpc-id,Values=${VpcId}" \
  --query 'Subnets[0].SubnetId' \
  --output text` && echo ${SubnetId0}
```

```
SubnetId1=`aws ec2 describe-subnets \
  --filters "Name=vpc-id,Values=${VpcId}" \
  --query 'Subnets[1].SubnetId' \
  --output text` && echo ${SubnetId1}
```

```
SubnetId2=`aws ec2 describe-subnets \
  --filters "Name=vpc-id,Values=${VpcId}" \
  --query 'Subnets[2].SubnetId' \
  --output text` && echo ${SubnetId2}
```

### result
```
subnet-04dd93ef1afe35a0f
```

```
subnet-0fb41eb669d8843bc
```

```
subnet-0fbc32308c5edd37a
```



## 10-07.SUBNETの削除
### cmd
```
aws ec2 delete-subnet \
  --subnet-id ${SubnetId0}
```

```
aws ec2 delete-subnet \
  --subnet-id ${SubnetId1}
```

```
aws ec2 delete-subnet \
  --subnet-id ${SubnetId2}
```

### result
```
none
```

```
none
```

```
none
```


## 10-08.VPCの削除
### cmd
```
aws ec2 delete-vpc \
  --vpc-id ${VpcId}
```
### result
```
none
```



## 10-09.IAM RolePolicyの削除
### cmd
```
aws iam delete-role-policy \
--role-name ${DevRoleName} \
--policy-name "AssumeRole"
```

### result
```
none
```



## 10-10.IAM Roleの管理ポリシーの削除
### cmd
```
aws iam detach-role-policy \
  --role-name ${DevRoleName} \
  --policy-arn "arn:aws:iam::aws:policy/AmazonEC2FullAccess"
```

```
aws iam detach-role-policy \
  --role-name ${DevRoleName} \
  --policy-arn "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
```

### result
```
none
```

```
none
```



## 10-11.IAM Roleの削除
### cmd
```
aws iam delete-role \
  --role-name ${DevRoleName}
```
### result
```
none
```
